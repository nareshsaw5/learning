package com.example.springdb.springdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
